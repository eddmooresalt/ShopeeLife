# ShopeeLife App
This is the ShopeeLife web app built using Next.js + Tailwind + ShadCN UI.